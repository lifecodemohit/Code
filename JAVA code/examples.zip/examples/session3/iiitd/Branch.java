package examples.session3.iiitd;

public enum Branch{
	CSE, ECE
}