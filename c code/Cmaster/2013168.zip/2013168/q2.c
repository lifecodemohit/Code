#include<stdio.h>
int print(char c)
{
    putchar(c);
}
int skip(char c)
{
    return;
}
int main(int argc, char* args[])
{
    int c;
    FILE *file;
    int n =0;
    char a;
    file = fopen("abc.txt", "r");
    if (file) {
        while ((c = getc(file)) != EOF)
        {
            putchar(c);
        }

        fclose(file);
    }
    else
        printf("File could not be opened.\n");
    return 0;
}
