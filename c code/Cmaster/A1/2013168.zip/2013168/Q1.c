#include<stdio.h>
int day_name(int n)
{
    char* name[7] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday" , "Saturday", "Sunday"};
    return name[n];
}
